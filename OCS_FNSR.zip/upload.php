<?php
include "config/config.inc.php";
include "controller/user_session.php";
include "controller/function.php";
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Konfirmasi Pembayaran - <?php echo $meta_title ?></title>
    <link rel="shortcut icon" type="image/x-icon" href="https://s13.postimg.org/kzn6gw7qf/skateboarder.png"/>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <meta name="description" content="<?php echo $meta_description ?>">
  <meta name="keywords" content="<?php echo $meta_keyword ?>">
  <meta name="author" content="<?php echo $meta_author ?>">
  <link rel="stylesheet" href="/asset/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="/asset/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="/asset/dist/css/skins/_all-skins.min.css">
  <link href="/asset/css/bootstrap-dialog.min.css" rel="stylesheet">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">



        <header class="main-header">
    
<a href="#" class="logo">
      
      <span class="logo-mini"><b>AHS Crew</b></span>
      
      <span class="logo-lg"><b><?php echo $nama_website ?></b></span>
    </a>
    
    <nav class="navbar navbar-static-top">
     
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
	
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="https://s23.postimg.org/plst1kfvf/fornesiacom.png" class="user-image" alt="User Image">  
		  <span class="hidden-xs"><?php echo $row['username'];?></span>
            </a>
            <ul class="dropdown-menu">
             
              <li class="user-header">
                <img src="https://s23.postimg.org/plst1kfvf/fornesiacom.png" class="img-circle" alt="User Image">
        
	
<p>
                  <?php echo $row['firstname']." ".$row['lastname'];?>
                  <small>Email: <?php echo $row['email'];?></small>
				  <small>Saldo: <?php echo $row['saldo'];?></small>
                </p>
			
  
 
		
              </li>
             
              <li class="user-body">
                <div class="row">
                </div>
                
              </li>

              <li class="user-footer">
                <div class="pull-left">
                  <a href="/home/setting" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="/logout" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>

          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header> 
  
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="https://i.imgur.com/mIcObyL.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $row['username'];?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Reseller</a>
        </div>
      </div>
      <!-- search form -->

      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li><a href="/userarea.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="/home/member/server"><i class="fa fa-shopping-cart"></i> <span>Beli Akun</span></a></li>
				<li class="treeview active">
		   <a href="#">
            <i class="fa fa-credit-card"></i> <span>Deposit</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="/deposit.php"><i class="fa fa-circle-o text-aqua"></i> Konfirmasi Pembayaran</a></li>
          </ul>
		          <li><a href="/home/setting"><i class="fa fa-circle-o text-aqua"></i> <span>Profile</span></a></li>
        </li>
        <li class="header">Bantuan</li>
        <li><a href="http://facebook.com"><i class="fa fa-circle-o text-yellow"></i> <span>Contact</span></a></li>
        <li><a href="/tos.html"><i class="fa fa-circle-o text-red"></i> <span>Peraturan Server</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  
    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Deposit Saldo
      </h1>
      <ol class="breadcrumb">
        <li><a href="/userarea.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="/deposit.php"> Deposit</a></li>
		<li class="active">Deposit Sukses</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
	
	       <div class="row">
		       
		
      <div class="col-xs-12">
          <div class="box box-success">
            <div class="box-header with-border">
           
            </div>
<div class="box-body">

<?php
include "controller/uploads.php";
?>

</div>
	

</div>

    </section>

  </div>
 

  <footer class="main-footer">
    <strong><?php echo $copyright ?> <?php echo $meta_author ?>.</strong> All rights
    reserved.
  </footer>

  <aside class="control-sidebar control-sidebar-dark">
      <table id="layout-skins-list" class="table nth-2-center">
        <thead>
          <tr>
            <th style="width: 200px;">Skin Setting</th>
            <th>Preview</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><code>Blue</code></td>
            <td><a href="#" data-skin="skin-blue" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Blue light</code></td>
            <td><a href="#" data-skin="skin-blue-light" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Yellow</code></td>
            <td><a href="#" data-skin="skin-yellow" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Yellow light</code></td>
            <td><a href="#" data-skin="skin-yellow-light" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Green</code></td>
            <td><a href="#" data-skin="skin-green" class="btn btn-success btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Green light</code></td>
            <td><a href="#" data-skin="skin-green-light" class="btn btn-success btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Purple</code></td>
            <td><a href="#" data-skin="skin-purple" class="btn bg-purple btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Purple light</code></td>
            <td><a href="#" data-skin="skin-purple-light" class="btn bg-purple btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Red</code></td>
            <td><a href="#" data-skin="skin-red" class="btn btn-danger btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Red light</code></td>
            <td><a href="#" data-skin="skin-red-light" class="btn btn-danger btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Black</code></td>
            <td><a href="#" data-skin="skin-black" class="btn bg-black btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Black light</code></td>
            <td><a href="#" data-skin="skin-black-light" class="btn bg-black btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
        </tbody>
      </table>

  
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
  
</div>
<!-- ./wrapper -->

<script src="/plugins/jQuery/jquery-2.2.3.min.js"></script>
<link rel="stylesheet" href="/asset/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.js"></script>
<link rel="stylesheet" href="/../plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="/../plugins/datepicker/datepicker3.css">
<script src="/asset/js/bootstrap.min.js"></script>
<script src="/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="/plugins/fastclick/fastclick.js"></script>
<script src="/asset/dist/js/app.min.js"></script>
<script src="/../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="/../plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $('#fornesia').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
  <script src="/../plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="/asset/js/bootstrap-dialog.min.js"></script>
    <script type="text/javascript">
        $('.input-group.date').datepicker({
            format: "yyyy/mm/dd",
            weekStart: 1,
            clearBtn: true,
            language: "id",
            autoclose: true,
            todayHighlight: true
        });
        $('.hapus').click(function(e) {
            e.preventDefault();
            BootstrapDialog.confirm({
                title: 'Confirm',
                message: ' Apakah Anda Yakin ?',
                type: BootstrapDialog.TYPE_DANGER,
                closable: true,
                btnCancelLabel: 'Batal',
                btnOKLabel: 'Delete',
                btnOKClass: 'btn-danger',
                callback: function(result) {
                    if(result) {
                        location.href = $('.hapus').attr('href');
                    }
                }
            });
        });
        function print_report() {
            window.print();
            return false;
        }
    </script>

</body>
</html>