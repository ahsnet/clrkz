<?php
$fnsett = "SELECT * from pengaturan";
$readfnsett = mysql_query($fnsett);
$datafns = mysql_fetch_array($readfnsett);
	$nama_website = $datafns['nama_website'];
	$meta_title = $datafns['meta_title'];
	$meta_description = $datafns['meta_description'];
	$meta_keyword = $datafns['meta_keyword'];
	$meta_author = $datafns['meta_author'];
	$copyright = $datafns['copyright'];

$query = "SELECT count(*) AS total FROM server"; 
$result = mysql_query($query); 
$values = mysql_fetch_assoc($result); 
$fns_server = $values['total']; 

$query2 = "SELECT count(*) AS total FROM user WHERE type ='2'"; 
$result2 = mysql_query($query2); 
$values2 = mysql_fetch_assoc($result2); 
$fns_user = $values2['total']; 

$query3 = "SELECT count(*) AS total FROM dataimage"; 
$result3 = mysql_query($query3); 
$values3 = mysql_fetch_assoc($result3); 
$fns_invoice = $values3['total']; 

$query4 = "SELECT count(*) AS total FROM user WHERE type ='1'"; 
$result4 = mysql_query($query4); 
$values4 = mysql_fetch_assoc($result4); 
$fns_admin = $values4['total']; 
?>	