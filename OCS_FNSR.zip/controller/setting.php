<?php
$fns = "SELECT * from pengaturan";
$readfns = mysql_query($fns);
$sett_result = mysql_fetch_array($readfns);
	$nama_website = $sett_result['nama_website'];
	$meta_title = $sett_result['meta_title'];
	$meta_description = $sett_result['meta_description'];
	$meta_keyword = $sett_result['meta_keyword'];
	$meta_author = $sett_result['meta_author'];
	$copyright = $sett_result['copyright'];

//$pengaturan_id =$_REQUEST['pengaturan_id'];

if(isset($_POST['save']))
{	
	$nama_website = $_POST['nama_website'];
	$meta_title = $_POST['meta_title'];
	$meta_description = $_POST['meta_description'];
	$meta_keyword = $_POST['meta_keyword'];
	$meta_author = $_POST['meta_author'];
	$copyright = $_POST['copyright'];
	
	mysql_query("UPDATE pengaturan SET nama_website ='$nama_website', meta_title ='$meta_title', meta_description ='$meta_description',
		 meta_keyword ='$meta_keyword',meta_author ='$meta_author',copyright ='$copyright'")
				or die(mysql_error()); 				
	echo "		<div class='alert alert-success alert-dismissible'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <h4><i class='fa fa-thumbs-o-up'></i> Sukses</h4>
                Pengaturan berhasil disimpan!
              </div>
	
	
	";
	
	//header("Location: pengaturan.php");			
}
?>