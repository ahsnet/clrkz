<?php	

$data = "SELECT * from dataimage";
$bacadata = mysql_query($data);
$numrows = mysql_num_rows($bacadata);
if($numrows == 0){
echo"
              <div class='callout callout-danger text-center'>
                <p>Belum ada data Pembayaran untuk saat ini.</p>
              </div>

";
  
} 
else{ 
while($select_result = mysql_fetch_array($bacadata))
{
$idimg        = $select_result['idimg'];	
$nama        = $select_result['nama'];
$transfer    = $select_result['transfer'];
$bank        = $select_result['bank'];
$emailakun        = $select_result['emailakun'];
$namauser        = $select_result['namauser'];
$newname        = $select_result['newname'];

$namafolder="gambar/";

echo"<tr><td>$emailakun</td><td>$namauser</td><td>$nama</td><td>$transfer</td><td>$bank</td><td><i class='fa fa-eye'></i> <a href='$namafolder$newname'>View</a></td><td><a href=\"lib/hapus.php?id=".$idimg."\"><i class='fa fa-trash'></i></a></td></tr>";
          
}
}
?>