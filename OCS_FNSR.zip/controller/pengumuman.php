<?php
$fnsnotice = "SELECT * from pengaturan";
$readnotice = mysql_query($fnsnotice);
$sett_result = mysql_fetch_array($readnotice);
	$pengumuman = $sett_result['pengumuman'];

//$pengaturan_id =$_REQUEST['pengaturan_id'];

if(isset($_POST['savenotice']))
{	
	$pengumuman = $_POST['pengumuman'];
	
	mysql_query("UPDATE pengaturan SET pengumuman ='$pengumuman'")
				or die(mysql_error()); 				
	echo "		<div class='alert alert-success alert-dismissible'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <h4><i class='fa fa-thumbs-o-up'></i> Sukses</h4>
                Pengumuman berhasil disimpan!
              </div>
	
	
	";
	
	//header("Location: pengaturan.php");			
}
?>