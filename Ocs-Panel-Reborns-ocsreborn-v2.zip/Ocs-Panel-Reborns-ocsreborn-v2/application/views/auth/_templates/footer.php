<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<center class="text-center">&copy; WEBSSH 2017</center>
<center>ALL Right Reserved</center>
</div>
</body>
</html>
